WR4                 02h41m11s +56d43m49s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_OCL132-20261113-2015-13x180s-f85.fits                                                            
48 c Per            04h08m40s +47d42m45s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_48Cper-20261031-2239-17x60s-f85.fits spectrum_hd25940_20261031_944.fits
M 76                01h42m00s +51d34m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_m76-20261107-1738-17x180s-f85.fits
OCL 132             02h37m00s +55d54m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_OCL132-20261113-2015-13x180s-f85.fits
V0488 Sge           19h45m00s +18d22m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_V0488Sge-20260911-2044-18x60s-f85.fits
Gam Cas             00h56m52s +60d43m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas-20260914-2021-21x30s-f85.fits
V0488 Sge           19h45m05s +18d22m05s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_V0488Sge-20260915-2012-30x180s-f85.fits
Gam Cas             00h56m52s +60d43m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas-20260915-2207-13x30s-f85.fits
WR5                 02h52m12s +56d56m07s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            
C* UV Cam           04h05m53s +61d47m40s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET                                                            
C* V0623 Cas        03h11m25s +57d54m11s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET      
Eps Cas             01h54m23s +63d40m12s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_EpsCas-20261004-1925-19x30s-f85.fits                                                      
Gam Cas             00h56m53s +60d44m00s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas_hd5394-20261001-1853-46x15s-f85.fits spectrum_hd5394_20261001_787.fits
Gam Cas             00h56m51s +60d44m01s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_GamCas_hd5394-20261006-1937-14x15s-f85.fits spectum_hd5394_20261006_817.fits
Del Cas             01h25m48s +60d14m07s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_DelCas-20261005-1946-40x30s-f85.fits
Alp Cas             00h40m30s +56d32m13s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_AlpCas-20261005-2025-20x30s-f85.fits
Bet Cas             00h09m12s +59d08m54s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_BetCas-20261005-2045-20x30s-f85.fits
HD 225136           00h03m51s +66d42m43s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_HD225136-20261006-2103-7x180s-f85.fits
52 Cas              02h02m52s +64d54m04s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_52Cas-20261004-1954-25x60s-f85.fits
HD 12468            02h04m40s +65d06m11s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_52Cas-20261004-1954-25x60s-f85.fits
HD 11946            01h59m38s +64d37m16s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum_52Cas-20261004-1954-25x60s-f85.fits
NGC 457             01h19m35s +58d17m12s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         Spectrum-ngc457-20261029-2220-10x180s-f85.fits
X Cas               01h56m38s +59d15m34s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         spectrum_XCas_20261029_2329-10x60s-f85.fits
Phi Per             01h43m39s +50d41m19s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         spectrum_HD10516-20261102-2111-30X60s-f85.fits spectrum_hd10516_20261102_883.fits
Psi Per             03h36m29s +48d11m32s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         spectrum-HD22192-20261031-2340-20x60s-f85.fits spectrum_hd22192_20261031_986.fits
Alp Ori             05h55m10s +07d24m45s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         TARGET 
HD 120933           13h51m47s +34d26m29s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         HD120933-20260407-2036-16x60s-f135.fits
HD 112185           12h54m02s +55d57m35s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         HD112185-20260411-2004-1x4s-f135.fits
HD 112185           12h54m05s +55d57m36s      1.00  20.00   00    Red,R,5   UV/IR-CUT SA200                         HD112185-20260411-1957-3x20s-f135.fits