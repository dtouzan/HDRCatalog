OCL 132             02h28m00s +56d36m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL132-20261113-1740-39x60s-f85.fits  
OCL 132             02h04m00s +56d12m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL132-20261113-1742-38x60s-f85.fits
OCL 132             02h19m00s +58d21m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL132-20261113-1834-33x60s-f85.fits
OCL 132             02h09m00s +59d26m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL132-20261113-1923-35x60s-f85.fits
OCL 132             02h40m00s +59d25m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL132-20261113-2015-35x60s-f85.fits
OCL 132             01h46m00s +61d00m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL132-20261114-1833-35x60s-f85.fits
NGC 1502            04h06m00s +62d45m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc1502-20261113-2200-30x60s-f85.fits
T CrB               15h55m00s +26d10m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260520-2226-9x60s-f85.fits
NGC 5907            15h14m00s +56d24m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc5907-20260520-2136-9x300s-f85.fits
M 13                16h41m00s +36d38m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m13-20260521-2110-30x60s-f85.fits
M 92                17h17m00s +43d06m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m92-20260521-2152-21x60s-f85.fits
T CrB               15h56m00s +26d03m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260522-2234-15x60s-f85.fits
148  asteroid       15h18m00s +18d08m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      148-20260522-2109-61x60s-f85.fits
NGC 6229            16h46m00s +47d32m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6229-20260523-2133-15x180s-f85.fits
X Her               15h54m00s +43d07m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         XHer-20260526-2121-15x30s-f85.fits
V* W Her            17h20m00s +32d32m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260526-2226-15x30s-f85.fits
M 57                18h54m00s +32d48m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m57-20260522-2303-27x60s-f85.fits
T CrB               15h50m00s +27d03m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260525-2150-15x30s-f85.fits
Del02 Lyr           18h52m00s +36d59m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         del02_Lyr-20260526-2209-15x30s-f85.fits
Ksi Her             18h05m00s +30d09m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ksi_Her-20260526-2137-15x60s-f85.fits
T CrB               15h56m00s +26d49m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260531-2129-15x60s-f85.fits
304 asteroid        15h49m00s +07d25m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      field 304_660_781-20260531-2154-12x60s-f85.fits
HD 188947           20h05m00s +33d51m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd188947-20260616-2213-15x180s-f85.fits
T CrB               15h58m00s +26d29m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260616-2142-16x30s-f85.fits
4451 asteroid       18h07m00s +20d55m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      field 4451-20260617-2147-30x60s-f85.fits
4451 asteroid       18h07m00s +20d47m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      field 4451-20260617-2228-44x30s-f85.fits
ic 4665             17h46m00s +05d39m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic4665-20260618-2205-15x60s-f85.fits
ic 4665             17h46m00s +05d39m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic4665-20260618-2227-30x30s-f85.fits
Cl 399              19h27m00s +20d20m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         Cl399-20260619-2248-27x60s-f85.fits
Cl 399              19h27m00s +20d19m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         Cl399-20260619-2324-40x30s-f85.fits
T CrB               15h56m00s +26d11m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260619-2133-49x30s-f85.fits
NGC 188             00h56m00s +85d24m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc188-20260621-2206-37x60s-f85.fits
V* W Her            17h20m00s +32d46m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260623-2151-27x30s-f85.fits
V* W Her            17h20m00s +32d45m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260623-2248-36x30s-f85.fits
T CrB               15h56m00s +26d08m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260624-2146-30x30s-f85.fits
V* W Her            16h35m00s +37d22m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260624-2219-50x30s-f85.fits
T CrB               15h58m00s +26d15m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    T_CrB-20260706-2136-15x30s-f85.fits
V* W Her            16h37m00s +37d17m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260706-2203-17x60s-f85.fits
at2026rdg           19h16m00s +11d57m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260706-2229-28x60s-f85.fits
V* W Her            16h38m00s +37d12m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260708-2139-34x30s-f85.fits
V* W Her            16h37m00s +37d15m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260710-2158-30x30s-f85.fits
at2026rdg           19h14m00s +12d14m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260710-2308-20x60s-f85.fits
M 29                20h19m00s +37d47m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m29-20260711-2221-30x60s-f85.fits
849 asteroid        18h44m00s +05d29m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      849-20260717-2232-15x60s-f85.fits
480 asteroid        18h44m00s +02d44m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      480-20260717-2254-15x60s-f85.fits
at2026rdg           19h13m00s +11d54m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260717-2209-15x60s-f85.fits
NGC 6823            19h45m00s +23d15m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6823-20260718-2241-30x60s-f85.fits
at2026rdg           19h14m00s +11d56m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260719-2150-29x60s-f85.fits
NGC 6823            19h45m00s +23d15m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6823-20260718-2241-30x60s-f85.fits
at2026rdg           19h14m00s +11d56m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260719-2150-29x60s-f85.fits
NGC 6823            19h45m00s +23d16m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6823-20260720-2127-60x60s-f85.fits
V* W Her            16h36m00s +37d15m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260723-2152-30x30s-f85.fits
NGC 6995            20h51m00s +30d49m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6995-20260724-2134-15x180s-f85.fits
M 39                21h26m00s +47d38m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m39-20260726-2151-30x30s-f85.fits
at2026rdg           19h14m00s +12d02m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260727-2152-35x60s-f85.fits
NGC 6882            20h12m00s +26d37m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6882-20260728-2139-30x30s-f85.fits
NGC 6940            20h34m00s +28d20m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc6940-20260729-2131-30x30s-f85.fits
V* W Her            16h35m00s +37d22m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260731-2103-30x30s-f85.fits
NGC 7039            21h17m00s +46d04m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7039-20260731-2214-30x30s-f85.fits
at2026rdg           19h14m00s +11d55m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260801-2128-30x60s-f85.fits
V* W Lyr            18h16m00s +36d32m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWLyr-20260803-2134-30x30s-f85.fits
ic 5146             21h59m00s +47d17m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic5146-20260805-2224-30x60s-f85.fits
NGC 7243            22h10m00s +49d14m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7243-20260805-2228-30x60s-f85.fits
NGC 7000            20h56m00s +44d19m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7000R-20260807-2129-21x180s-f85.fits
V* T Her            18h09m00s +31d00m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VTHer-20260806-2119-30x30s-f85.fits
V* W Her            16h37m00s +37d15m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260808-2045-30x30s-f85.fits
at2026rdg           19h14m00s +12d11m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         at2026rdg-20260808-2114-30x60s-f85.fits
NGC 7023            21h04m00s +67d58m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7023-20260809-2107-35x180s-f85.fits
V* W Her            16h36m00s +37d17m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260813-2021-30x10s-f85.fits
M 31                00h42m00s +41d12m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m31-20260814-2233-19x60s-f85.fits
V* W Her            16h35m00s +37d17m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         VWHer-20260813-2041-20x30s-f85.fits
NGC 7380            22h53m00s +58d38m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7380-20260812-2147-21x180s-f85.fits
V* V0488 Sge        19h43m00s +17d55m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         V0488Sge-20260909-2034-35x30s-f85.fits
V* V0488 Sge        19h42m00s +18d07m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         V0488Sge_20260911-1942-30x30s-f85.fits
Cl 399              19h29m00s +20d09m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         cl399-20260911-2013-30x30s-f85.fits
M 71                19h49m00s +18d11m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         M71-20260911-2047-21x30s-f85.fits
NGC 7000            20h55m00s +44d32m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7000-20260911-2140-88x30s-f85.fits
S Cas               01h19m00s +72d45m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         SCas-20260920-2010-15x60s-f85.fits
NGC 7538            23h04m00s +63d11m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7538-20260920-2053-76x60s-f85.fits
NGC 7380            22h48m00s +59d18m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7380-20260921-1950-61x60s-f85.fits
ic 1590             00h55m00s +57d28m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1590-20260921-2130-63x60s-f85.fits
NGC 7822            00h05m00s +68d00m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc7822-20260922-1947-80x60s-f85.fits         
SN 2026aaiv         22h37m00s +35d20m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         sn2026aaiv-20260922-2142-43x60s-f285.fits                                 
695 asteroid        23h45m00s +26d16m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      695-20260922-2028-44x30s-f70.fits
71 asteroid         23h27m00s +23d54m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      71-20260922-2126-48x60s-f70.fits
Stock 5             02h12m00s +65d07m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         Stock5-20261001-1941-104x60s-f85.fits
M 103               01h44m00s +60d09m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m103-20261005-1950-21x60s-f85.fits
ic 1590             00h56m00s +56d04m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1590-20261005-2041-12x60s-f85.fits
ic 1805             02h34m00s +63d02m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1805-20261013-1952-20x60s-f85.fits
ic 1805             02h43m00s +63d12m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1805-20261013-1952-20x60s-f85.fits
ic 1805             02h50m00s +61d20m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1805-20261013-1952-20x60s-f85.fits
ic 1805             02h47m00s +60d34m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1805-20261013-1952-20x60s-f85.fits
ic 1805             02h38m00s +61d05m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ic1805-20261013-1952-20x60s-f85.fits
NGC 103             00h17m00s +62d23m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc103-20261030-1852-60x60s-f85.fits
687 asteroid        00h50m00s +31d22m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      687-20261031-1906-60x60s-f85.fits
375 asteroid        01h29m00s +31d24m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      375-20261031-1911-70x60s-f85.fits
NGC 1528            04h05m00s +51d52m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc1528-20261031-2115-54x60s-f85.fits
NGC 1499            04h02m00s +37d05m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc1499-20261102-2119-44x180s-f85.fits
OCL 6463            01h43m00s +71d57m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         OCL6463-20261114-2013-28x60s-f85.fits
2105 asteroid       04h43m00s +51d11m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      2105-20261113-2247-42x60s-f85.fits
NGC 4205            12h19m00s +64d49m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc4205-20260507-2053-25x60s-f85.fits
NGC 5907            15h15m00s +56d43m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc5907-20260507-2130-25x60s-f85.fits
M 94                12h48m00s +41d25m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m94-20260422-2039-84x60s-f85.fits
HD 143454           15h56m00s +26d46m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    hd143454-20260423-2204-17x60s-f85.fits
1727 asteroid       14h33m00s +30d29m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      1727-20260424-2052-65x60s-f85.fits
NGC 5033            13h08m00s +36d48m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc5033-20260418-2009-64x60s-f85.fits
HD 143454           16h54m00s +26d42m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Symbiotic*                    hd143454-20260420-2215-28x60s-f85.fits
SN 2026fvx          12h13m00s +63d55m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Supernova                     sn2026fvx-20260415-2039-4x60s-f85.fits
M 63                13h13m00s +41d30m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m63-20260420-2030-61x60s-f85.fits
sn2026fvx           12h13m00s +63d43m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT Supernova                     sn2026fvx-20260411-2009-57x60s-f85.fits
511 asteroid        10h27m00s +28d36m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      511-20260413-2015-68x60s-f85.fits
HD 143454           15h55m00s +26d42m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd143454-20260413-2207-19x60s-f85.fits
NGC 2683            08h58m00s +32d28m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc2683-20260407-2039-13x60s-f85.fits
HD 143454           15h49m00s +26d54m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd143454-20260408-2302-15x60s-f85.fits
928 asteroid        12h53m00s +21d00m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      928-20260405-2021-23x60s-f85.fits
M 64                12h59m00s +20d23m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m64-20260321-2306-21x60s-f85.fits
M 82                10h04m00s +70d33m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m82-20260405-2146-31x60s-f85.fits
350 asteroid        12h41m00s +33d03m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      350-20260319-2105-57x60s-f85.fits
1303 asteroid       12h54m00s +24d30m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      1303-20260319-2233-10x60s-f85.fits
M 3                 13h41m00s +28d26m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m3-20260321-2156-57x60s-f85.fits
326 asteroid        12h20m00s +18d54m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      326-20260406-2026-75x60s-f85.fits
1090 asteroid       12h53m00s +25d16m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      1090-20260407-2114-41x60s-f85.fits
NGC 4725            12h55m00s +24d54m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc4725-20260321-2232-21x60s-f85.fits
977 asteroid        10h58m00s +29d32m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      977-20260402-2117-8x60s-f85.fits
HD 64511            07h56m00s +22d09m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd64511-20260318-1958-35x60s-f85.fits
M 53                13h09m00s +17d50m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m53-20260317-2133-78x60s-f85.fits
HD 114710           12h58m00s +26d21m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd114710-20260317-2352-21x60s-f85.fits
HD 109387           12h39m00s +70d49m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd109387-20260328-2143-11x60s-f85.fits
679 asteroid        12h39m00s +31d31m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      679-20260328-2029-69x60s-f85.fits
M 64                13h02m00s +22d24m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m64-20260317-2242-21x60s-f85.fits
M 53                13h04m00s +18d50m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m53-20260317-2311-21x60s-f85.fits
NGC 4244            12h15m00s +37d08m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc4244-20260318-2101-46x60s-f85.fits
863 asteroid        09h19m00s +33d52m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      863-20260321-1944-24x60s-f85.fits
NGC 4565            12h39m00s +26d36m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         ngc4565-20260314-2217-21x60s-f85.fits
HD 64511            07h55m00s +22d00m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd64511-20260314-1931-31x60s-f85.fits
M 51                13h27m00s +47d14m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         m51-20260314-2247-13x60s-f85.fits
M 40                12h20m00s +57d56m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         M40-20260308-2147-12x300s-f85.fits
HD 64511            07h55m00s +21d58m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd64511-20260311-2020-24x60s-f85.fits
HD 64511            07h55m00s +22d04m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         hd64511-20260317-1931-37x60s-f85.fits
1252 asteroid       11h30m00s +29d18m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT asteroid                      1252-20260303-2207-26x30s-f85.fits
M 40                12h21m00s +57d50m00s      1.00  200.00  00    Green,V,6 UV/IR-CUT field                         M40-20260304-2018-85x60s-f85.fits